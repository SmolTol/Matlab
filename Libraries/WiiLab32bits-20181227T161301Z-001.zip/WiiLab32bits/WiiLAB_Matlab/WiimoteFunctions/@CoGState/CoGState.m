% Center of Gravity values from the Wiimote (Balance Board)

classdef CoGState
    
    properties 
        
        X = 0;
        Y = 0;
        
    end % properties
    
end
    