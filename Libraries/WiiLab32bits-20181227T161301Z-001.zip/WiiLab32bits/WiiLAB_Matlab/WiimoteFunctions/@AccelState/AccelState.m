% AccelState is the class that creates the data structure for storing the
% AccelState values from the Wiimote

classdef AccelState
    
    properties 
        
        X = 0;
        Y = 0;
        Z = 0;
        
    end % properties
    
end
    